#!/bin/sh

#$ -S /bin/sh
#$ -N repeatmodeler
#$ -o ../logs/$JOB_NAME.out.$JOB_ID
#$ -e ../logs/$JOB_NAME.err.$JOB_ID
#$ -cwd
#$ -l h_vmem=20G
#$ -q intel.q
####$ -pe openmpi 2
###$ -q amd.q
###$ -t 1-22

#
# maxvmem 3.753G
# walltime 121320 (34hrs)
# build database of denovo identified repeats

RMOD='/ibers/ernie/home/rov/programs/RepeatModeler'
SEQ='/ibers/ernie/scratch/rov/zipper_003/ref2/atlan20131014_010_min200.fa'
DB='avena_atlantica_002'

${RMOD}/BuildDatabase -name ${DB} ${SEQ}
${RMOD}/RepeatModeler -database ${DB}
